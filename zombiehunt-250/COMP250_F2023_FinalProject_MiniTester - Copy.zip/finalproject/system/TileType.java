package finalproject.system;

public enum TileType {
    Plain,
    Forest,
    Moutain,
    Metro,
    Facility,
    Desert,
    ZombieInfectedRuin
}
