package finalproject.tiles;

import finalproject.system.Tile;
import finalproject.system.TileType;

public class DesertTile extends Tile {
    //TODO level 0: finish constructor
    public DesertTile() {
        this.type = TileType.Desert;
    }
}
